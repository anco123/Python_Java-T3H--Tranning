package com.logicbig.example.service;


public interface HelloWorldService {

    void sayHi(String name);
}